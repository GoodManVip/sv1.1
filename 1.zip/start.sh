#!/bin/bash
while true
do
{
    sleep 3s
    
	java -Xmx512M -jar server.jar
}
done